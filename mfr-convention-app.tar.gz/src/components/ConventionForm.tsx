import { useState, useEffect } from 'react';
import { ArrowLeft, ArrowRight, Save } from 'lucide-react';
import { Convention, StagePeriod } from '../types/convention';
import { getConventionType } from '../utils/conventionTypeHelper';

interface ConventionFormProps {
  onSubmit: (convention: Convention, periods: StagePeriod[]) => void;
  initialData?: Convention;
}

export function ConventionForm({ onSubmit, initialData }: ConventionFormProps) {
  const [step, setStep] = useState(1);
  const [convention, setConvention] = useState<Convention>(initialData || {
    status: 'draft',
    is_minor: false,
  });
  const [periods, setPeriods] = useState<StagePeriod[]>([
    { period_number: 1, start_date: '', end_date: '', daily_hours: '' }
  ]);

  const updateConvention = (field: keyof Convention, value: any) => {
    setConvention(prev => ({ ...prev, [field]: value }));
  };

  // Mettre à jour le type de convention quand la classe change
  useEffect(() => {
    if (convention.student_class) {
      try {
        const conventionType = getConventionType(convention.student_class);
        setConvention(prev => ({ ...prev, convention_type: conventionType }));
      } catch (error) {
        console.error('Erreur lors de la détermination du type de convention:', error);
      }
    }
  }, [convention.student_class]);

  const addPeriod = () => {
    if (periods.length < 7) {
      setPeriods([...periods, {
        period_number: periods.length + 1,
        start_date: '',
        end_date: '',
        daily_hours: ''
      }]);
    }
  };

  const removePeriod = (index: number) => {
    setPeriods(periods.filter((_, i) => i !== index));
  };

  const updatePeriod = (index: number, field: keyof StagePeriod, value: string) => {
    const newPeriods = [...periods];
    newPeriods[index] = { ...newPeriods[index], [field]: value };
    setPeriods(newPeriods);
  };

  const handleSubmit = () => {
    onSubmit(convention, periods);
  };

  const canGoNext = () => {
    if (step === 1) {
      return convention.student_class && convention.company_name && convention.company_siren && convention.student_lastname && convention.student_firstname;
    }
    if (step === 2) {
      return periods.every(p => p.start_date && p.end_date);
    }
    return true;
  };

  return (
    <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-lg p-8">
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-3xl font-bold text-gray-900">Convention de stage</h1>
          <div className="text-sm text-gray-600">Étape {step} sur 3</div>
        </div>
        <div className="flex gap-2">
          {[1, 2, 3].map(s => (
            <div
              key={s}
              className={`h-2 flex-1 rounded-full transition ${
                s <= step ? 'bg-blue-600' : 'bg-gray-200'
              }`}
            />
          ))}
        </div>
      </div>

      {step === 1 && (
        <div className="space-y-6">
          <div className="bg-blue-50 border-2 border-blue-300 rounded-lg p-6 mb-6">
            <h2 className="text-2xl font-bold text-blue-900 mb-3">
              1. Choisir la classe de l'élève
            </h2>
            <p className="text-sm text-blue-800 mb-4">
              Ce choix détermine le type de convention à remplir (stages d'initiation pour 4ème/3ème ou PFMP pour 2nde/1ère/Term)
            </p>
            <div className="bg-white rounded-lg p-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Classe de l'élève *
              </label>
              <select
                value={convention.student_class || ''}
                onChange={e => updateConvention('student_class', e.target.value)}
                className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-lg"
                required
              >
                <option value="">-- Sélectionner la classe --</option>
                <option value="4ème">4ème</option>
                <option value="3èmeA">3ème A</option>
                <option value="3èmeN">3ème N</option>
                <option value="2nde1">2nde 1</option>
                <option value="2nde2">2nde 2</option>
                <option value="1ère1">1ère 1</option>
                <option value="1ère2">1ère 2</option>
                <option value="Term1">Term 1</option>
                <option value="Term2">Term 2</option>
              </select>
              {convention.student_class && (
                <p className="mt-2 text-sm text-green-700 font-medium">
                  ✓ Convention {
                    ['4ème', '3èmeA', '3èmeN'].includes(convention.student_class)
                      ? "de stages d'initiation"
                      : ['2nde1', '2nde2'].includes(convention.student_class)
                      ? 'PFMP Seconde'
                      : 'PFMP 1ère/Terminale'
                  } sélectionnée
                </p>
              )}
            </div>
          </div>

          <div>
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Informations Entreprise</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Nom de l'entreprise *
                </label>
                <input
                  type="text"
                  value={convention.company_name || ''}
                  onChange={e => updateConvention('company_name', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  SIREN/SIRET *
                </label>
                <input
                  type="text"
                  value={convention.company_siren || ''}
                  onChange={e => updateConvention('company_siren', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Lieu de stage
                </label>
                <input
                  type="text"
                  value={convention.stage_location || ''}
                  onChange={e => updateConvention('stage_location', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Nom du signataire
                </label>
                <input
                  type="text"
                  value={convention.company_signatory_lastname || ''}
                  onChange={e => updateConvention('company_signatory_lastname', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Prénom du signataire
                </label>
                <input
                  type="text"
                  value={convention.company_signatory_firstname || ''}
                  onChange={e => updateConvention('company_signatory_firstname', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Qualité
                </label>
                <input
                  type="text"
                  value={convention.company_signatory_title || ''}
                  onChange={e => updateConvention('company_signatory_title', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Téléphone
                </label>
                <input
                  type="tel"
                  value={convention.company_phone || ''}
                  onChange={e => updateConvention('company_phone', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email
                </label>
                <input
                  type="email"
                  value={convention.company_email || ''}
                  onChange={e => updateConvention('company_email', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
          </div>

          <div>
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Informations Élève</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Nom *
                </label>
                <input
                  type="text"
                  value={convention.student_lastname || ''}
                  onChange={e => updateConvention('student_lastname', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Prénom *
                </label>
                <input
                  type="text"
                  value={convention.student_firstname || ''}
                  onChange={e => updateConvention('student_firstname', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Sexe
                </label>
                <select
                  value={convention.student_gender || ''}
                  onChange={e => updateConvention('student_gender', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Sélectionner</option>
                  <option value="M">Masculin</option>
                  <option value="F">Féminin</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Date de naissance
                </label>
                <input
                  type="date"
                  value={convention.student_birthdate || ''}
                  onChange={e => {
                    updateConvention('student_birthdate', e.target.value);
                    const birthDate = new Date(e.target.value);
                    const today = new Date();
                    const age = today.getFullYear() - birthDate.getFullYear();
                    updateConvention('is_minor', age < 18);
                  }}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Adresse
                </label>
                <input
                  type="text"
                  value={convention.student_address || ''}
                  onChange={e => updateConvention('student_address', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Téléphone
                </label>
                <input
                  type="tel"
                  value={convention.student_phone || ''}
                  onChange={e => updateConvention('student_phone', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email
                </label>
                <input
                  type="email"
                  value={convention.student_email || ''}
                  onChange={e => updateConvention('student_email', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
          </div>

          {convention.is_minor && (
            <div>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Responsable Légal</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Nom
                  </label>
                  <input
                    type="text"
                    value={convention.guardian_lastname || ''}
                    onChange={e => updateConvention('guardian_lastname', e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Prénom
                  </label>
                  <input
                    type="text"
                    value={convention.guardian_firstname || ''}
                    onChange={e => updateConvention('guardian_firstname', e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Adresse
                  </label>
                  <input
                    type="text"
                    value={convention.guardian_address || ''}
                    onChange={e => updateConvention('guardian_address', e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Téléphone
                  </label>
                  <input
                    type="tel"
                    value={convention.guardian_phone || ''}
                    onChange={e => updateConvention('guardian_phone', e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email
                  </label>
                  <input
                    type="email"
                    value={convention.guardian_email || ''}
                    onChange={e => updateConvention('guardian_email', e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {step === 2 && (
        <div className="space-y-6">
          <div>
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Caractéristiques du stage</h2>
            <div className="space-y-4">
              {periods.map((period, index) => (
                <div key={index} className="p-4 border border-gray-200 rounded-lg">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-medium text-gray-900">Période {index + 1}</h3>
                    {periods.length > 1 && (
                      <button
                        onClick={() => removePeriod(index)}
                        className="text-red-600 hover:text-red-700 text-sm"
                      >
                        Supprimer
                      </button>
                    )}
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Date de début *
                      </label>
                      <input
                        type="date"
                        value={period.start_date}
                        onChange={e => updatePeriod(index, 'start_date', e.target.value)}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Date de fin *
                      </label>
                      <input
                        type="date"
                        value={period.end_date}
                        onChange={e => updatePeriod(index, 'end_date', e.target.value)}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Horaires journaliers
                      </label>
                      <input
                        type="text"
                        placeholder="Ex: 9h-17h"
                        value={period.daily_hours || ''}
                        onChange={e => updatePeriod(index, 'daily_hours', e.target.value)}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                  </div>
                </div>
              ))}
              {periods.length < 7 && (
                <button
                  onClick={addPeriod}
                  className="w-full py-2 border-2 border-dashed border-gray-300 rounded-lg text-gray-600 hover:border-blue-500 hover:text-blue-600 transition"
                >
                  + Ajouter une période
                </button>
              )}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Principales tâches confiées au stagiaire
            </label>
            <textarea
              value={convention.main_tasks || ''}
              onChange={e => updateConvention('main_tasks', e.target.value)}
              rows={6}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Décrivez les tâches principales du stagiaire..."
            />
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="space-y-6">
          <div>
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Lieu et date de signature</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Fait à
                </label>
                <input
                  type="text"
                  value={convention.signing_location || ''}
                  onChange={e => updateConvention('signing_location', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Le
                </label>
                <input
                  type="date"
                  value={convention.signing_date || ''}
                  onChange={e => updateConvention('signing_date', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h3 className="font-semibold text-blue-900 mb-2">Récapitulatif</h3>
            <div className="text-sm text-blue-800 space-y-1">
              <p>• Entreprise: {convention.company_name}</p>
              <p>• Élève: {convention.student_firstname} {convention.student_lastname}</p>
              <p>• Nombre de périodes: {periods.length}</p>
              <p>• Statut: {convention.is_minor ? 'Mineur (5 signatures requises)' : 'Majeur (4 signatures requises)'}</p>
            </div>
          </div>
        </div>
      )}

      <div className="flex items-center justify-between mt-8 pt-6 border-t border-gray-200">
        <button
          onClick={() => setStep(Math.max(1, step - 1))}
          disabled={step === 1}
          className="flex items-center gap-2 px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <ArrowLeft className="w-4 h-4" />
          Précédent
        </button>

        {step < 3 ? (
          <button
            onClick={() => setStep(step + 1)}
            disabled={!canGoNext()}
            className="flex items-center gap-2 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Suivant
            <ArrowRight className="w-4 h-4" />
          </button>
        ) : (
          <button
            onClick={handleSubmit}
            className="flex items-center gap-2 px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition"
          >
            <Save className="w-4 h-4" />
            Enregistrer
          </button>
        )}
      </div>
    </div>
  );
}
