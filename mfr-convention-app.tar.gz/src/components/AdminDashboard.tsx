import { useState, useEffect } from 'react';
import { FileText, CheckCircle, Clock, Download, Eye, Trash2, Filter } from 'lucide-react';
import { Convention } from '../types/convention';
import { supabase } from '../lib/supabase';

interface AdminDashboardProps {
  onViewConvention: (convention: Convention) => void;
}

export function AdminDashboard({ onViewConvention }: AdminDashboardProps) {
  const [conventions, setConventions] = useState<Convention[]>([]);
  const [filter, setFilter] = useState<'all' | 'pending' | 'signed'>('all');
  const [classFilter, setClassFilter] = useState<string>('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadConventions();
  }, []);

  const loadConventions = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('conventions')
        .select('*')
        .order('created_at', { ascending: false });

      if (!error && data) {
        setConventions(data);
      }
    } catch (error) {
      console.error('Error loading conventions:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (conventionId: string) => {
    if (!confirm('Êtes-vous sûr de vouloir supprimer cette convention ? Cette action est irréversible.')) {
      return;
    }

    try {
      // Delete signatures first (cascade should handle this but let's be explicit)
      await supabase
        .from('signatures')
        .delete()
        .eq('convention_id', conventionId);

      // Delete stage periods
      await supabase
        .from('stage_periods')
        .delete()
        .eq('convention_id', conventionId);

      // Delete convention
      const { error } = await supabase
        .from('conventions')
        .delete()
        .eq('id', conventionId);

      if (error) throw error;

      // Reload conventions
      await loadConventions();
    } catch (error) {
      console.error('Error deleting convention:', error);
      alert('Erreur lors de la suppression de la convention');
    }
  };

  const filteredConventions = conventions.filter(conv => {
    const statusMatch =
      filter === 'all' ? true :
      filter === 'pending' ? conv.status !== 'ready_to_print' :
      filter === 'signed' ? conv.status === 'ready_to_print' : true;

    const classMatch =
      classFilter === 'all' ? true : conv.student_class === classFilter;

    return statusMatch && classMatch;
  });

  const getFilteredStats = () => {
    const filtered = conventions.filter(conv => {
      if (classFilter === 'all') return true;
      return conv.student_class === classFilter;
    });

    return {
      total: filtered.length,
      pending: filtered.filter(c => c.status !== 'ready_to_print').length,
      signed: filtered.filter(c => c.status === 'ready_to_print').length,
    };
  };

  const stats = getFilteredStats();

  const exportToCSV = () => {
    const headers = [
      'ID',
      'Statut',
      'Élève',
      'Entreprise',
      'Classe',
      'Date création',
      'Mineur',
    ];

    const rows = conventions.map(conv => [
      conv.id,
      conv.status,
      `${conv.student_firstname} ${conv.student_lastname}`,
      conv.company_name,
      conv.student_class,
      new Date(conv.created_at!).toLocaleDateString('fr-FR'),
      conv.is_minor ? 'Oui' : 'Non',
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(',')),
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `conventions_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  const getStatusBadge = (status: string) => {
    const badges = {
      draft: { label: 'Brouillon', color: 'bg-gray-100 text-gray-700' },
      pending_signatures: { label: 'En attente', color: 'bg-yellow-100 text-yellow-700' },
      signed: { label: 'Signée', color: 'bg-blue-100 text-blue-700' },
      ready_to_print: { label: 'Prête à imprimer', color: 'bg-green-100 text-green-700' },
    };

    const badge = badges[status as keyof typeof badges] || badges.draft;
    return (
      <span className={`px-3 py-1 rounded-full text-xs font-medium ${badge.color}`}>
        {badge.label}
      </span>
    );
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Chargement...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Tableau de bord administrateur</h1>
          <p className="text-gray-600">Gérez et suivez toutes les conventions de stage</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Total</p>
                <p className="text-3xl font-bold text-gray-900">{stats.total}</p>
              </div>
              <FileText className="w-12 h-12 text-blue-600 opacity-20" />
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">En attente</p>
                <p className="text-3xl font-bold text-yellow-600">{stats.pending}</p>
              </div>
              <Clock className="w-12 h-12 text-yellow-600 opacity-20" />
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Signées</p>
                <p className="text-3xl font-bold text-green-600">{stats.signed}</p>
              </div>
              <CheckCircle className="w-12 h-12 text-green-600 opacity-20" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow">
          <div className="p-6 border-b border-gray-200">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div className="flex flex-col gap-4">
                <div className="flex items-center gap-2">
                  <Filter className="w-5 h-5 text-gray-600" />
                  <span className="text-sm font-medium text-gray-700">Filtrer par classe :</span>
                  <select
                    value={classFilter}
                    onChange={(e) => setClassFilter(e.target.value)}
                    className="px-3 py-1.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent"
                  >
                    <option value="all">Toutes les classes</option>
                    <option value="4ème">4ème</option>
                    <option value="3èmeA">3ème A</option>
                    <option value="3èmeN">3ème N</option>
                    <option value="2nde1">2nde 1</option>
                    <option value="2nde2">2nde 2</option>
                    <option value="1ère1">1ère 1</option>
                    <option value="1ère2">1ère 2</option>
                    <option value="Term1">Term 1</option>
                    <option value="Term2">Term 2</option>
                  </select>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => setFilter('all')}
                    className={`px-4 py-2 rounded-lg transition ${
                      filter === 'all'
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    Toutes
                  </button>
                  <button
                    onClick={() => setFilter('pending')}
                    className={`px-4 py-2 rounded-lg transition ${
                      filter === 'pending'
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    En attente
                  </button>
                  <button
                    onClick={() => setFilter('signed')}
                    className={`px-4 py-2 rounded-lg transition ${
                      filter === 'signed'
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    Signées
                  </button>
                </div>
              </div>
              <button
                onClick={exportToCSV}
                className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition"
              >
                <Download className="w-4 h-4" />
                Exporter CSV
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Élève
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Entreprise
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Classe
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Statut
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Date
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredConventions.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-6 py-12 text-center text-gray-500">
                      Aucune convention trouvée
                    </td>
                  </tr>
                ) : (
                  filteredConventions.filter(conv => conv.id).map(conv => (
                    <tr key={conv.id} className="hover:bg-gray-50 transition">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="font-medium text-gray-900">
                          {conv.student_firstname} {conv.student_lastname}
                        </div>
                        {conv.is_minor && (
                          <span className="text-xs text-gray-500">Mineur</span>
                        )}
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-gray-900">{conv.company_name}</div>
                        <div className="text-xs text-gray-500">{conv.company_siren}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {conv.student_class || '-'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {getStatusBadge(conv.status)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {new Date(conv.created_at!).toLocaleDateString('fr-FR')}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center gap-3">
                          <button
                            onClick={() => onViewConvention(conv)}
                            className="flex items-center gap-1 text-blue-600 hover:text-blue-700 transition"
                            title="Voir la convention"
                          >
                            <Eye className="w-4 h-4" />
                            Voir
                          </button>
                          <button
                            onClick={() => handleDelete(conv.id!)}
                            className="flex items-center gap-1 text-red-600 hover:text-red-700 transition"
                            title="Supprimer la convention"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
