export type ConventionType = 'stage_initiation' | 'pfmp_seconde' | 'pfmp_premiere_terminale';

export interface Convention {
  id?: string;
  status: 'draft' | 'pending_signatures' | 'signed' | 'ready_to_print';
  convention_type?: ConventionType;
  created_by?: string;
  created_at?: string;
  updated_at?: string;

  company_name?: string;
  company_siren?: string;
  company_signatory_lastname?: string;
  company_signatory_firstname?: string;
  company_signatory_title?: string;
  company_phone?: string;
  company_email?: string;
  stage_location?: string;

  student_lastname?: string;
  student_firstname?: string;
  student_gender?: 'M' | 'F';
  student_birthdate?: string;
  student_address?: string;
  student_phone?: string;
  student_email?: string;
  student_class?: string;

  is_minor?: boolean;
  guardian_lastname?: string;
  guardian_firstname?: string;
  guardian_address?: string;
  guardian_phone?: string;
  guardian_email?: string;

  main_tasks?: string;
  signing_location?: string;
  signing_date?: string;
}

export interface StagePeriod {
  id?: string;
  convention_id?: string;
  period_number: number;
  start_date: string;
  end_date: string;
  daily_hours?: string;
}

export interface Signature {
  id?: string;
  convention_id?: string;
  signer_role: 'student' | 'parent' | 'maitre_stage' | 'responsable_classe' | 'chef_etablissement';
  signer_name: string;
  signer_email?: string;
  signature_data: string;
  signed_at?: string;
  ip_address?: string;
  user_agent?: string;
}

export interface User {
  id?: string;
  email: string;
  full_name: string;
  role: 'admin' | 'chef_etablissement' | 'responsable_classe' | 'eleve' | 'maitre_stage' | 'parent';
  created_at?: string;
}
